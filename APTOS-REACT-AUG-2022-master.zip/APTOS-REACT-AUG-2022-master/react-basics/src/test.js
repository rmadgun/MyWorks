console.log('start of script');
setTimeout(() => console.log('after 0 seconds...'), 0);
console.log('end of script');
