export type ITodo = {
    id: number;
    task: string;
    finished: boolean;
}