export function increment() {
    return { type: 'INC' }
}
export function decrement() {
    return { type: 'DEC' }
}
export function doubleUp() {
    return { type: 'DOUBLE_UP' }
}