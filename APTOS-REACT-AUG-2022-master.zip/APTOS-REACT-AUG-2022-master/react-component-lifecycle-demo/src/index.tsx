import ReactDOM from 'react-dom/client';
import AppFc from './AppFc';

const root = ReactDOM.createRoot(
    document.getElementById('root') as HTMLElement
);
root.render(<AppFc />);
