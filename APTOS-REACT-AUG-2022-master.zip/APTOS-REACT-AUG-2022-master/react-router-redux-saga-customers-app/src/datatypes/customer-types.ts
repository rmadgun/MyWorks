export interface ICustomer {
    id: number;
    firstname: string;
    lastname: string;
    gender: string;
    email: string;
    city: string;
    avatar: string;
}