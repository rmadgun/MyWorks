import React, { Component } from 'react'

export class About extends Component {
  render() {
    return (
      <div>About</div>
    )
  }
}

export default About