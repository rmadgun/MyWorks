import React, { Component } from 'react'

export class CustomerForm extends Component {
  render() {
    return (
      <div>CustomerForm</div>
    )
  }
}

export default CustomerForm